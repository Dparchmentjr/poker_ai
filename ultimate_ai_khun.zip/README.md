# poker_ai
by 
Austin Nowak
Joannier Pinales
Dane Partchment 
# run 

./ultimate_ai_khun.sh <ip> <port> 




